import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="cs304dbi", # Replace with your own username
    version="0.0.1",
    author="Scott D. Anderson",
    author_email="scott.anderson@acm.org",
    description="Functions to read database credentials and connect to a MySQL/MariaDB database",
    long_description=long_description,
    # the following is in the docs but always causes complaints
    # long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

# Execute this file as python setup.py sdist to
# get the package ready for installation
